public class BarangRental {

    String nomorTNKB;
    String namaKendaraan;
    String jenis;
    int tahun;
    int biayaSewaPerjam;

    public BarangRental(String nomorTNKB, String namaKendaraan, String jenis, int tahun, int biayaSewaPerjam) {
        this.nomorTNKB = nomorTNKB;
        this.namaKendaraan = namaKendaraan;
        this.jenis = jenis;
        this.tahun = tahun;
        this.biayaSewaPerjam = biayaSewaPerjam;
    }

    @Override
    public String toString() {
        return String.format("%s\t%s\t%s\t%d\t%d", nomorTNKB, namaKendaraan, jenis, tahun, biayaSewaPerjam);
    }
}

