import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Scanner;

public class TransaksiRentalKendaraan {

    static ArrayList<BarangRental> daftarKendaraan = new ArrayList<>();
    static ArrayList<Transaksi> daftarTransaksi = new ArrayList<>();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        initDaftarKendaraan();

        while (true) {
            System.out.println("++++++++++++++++++++");
            System.out.println("RENTAL SERBA SERBI");
            System.out.println("+++++++++++++++++++++");

            System.out.println("\nMenu:");
            System.out.println("1. Daftar Kendaraan");
            System.out.println("2. Peminjaman");
            System.out.println("3. Tampilkan seluruh transaksi");
            System.out.println("4. Urutkan Transaksi urut no TNKB");
            System.out.println("5. Keluar");
            System.out.print("Pilih (1-5): ");
            int pilihan = scanner.nextInt();

            switch (pilihan) {
                case 1:
                    tampilkanDaftarKendaraan();
                    break;
                case 2:
                    melakukanPeminjaman(scanner);
                    break;
                case 3:
                    tampilkanSeluruhTransaksi();
                    break;
                case 4:
                    urutkanTransaksiBerdasarkanTNKB();
                    break;
                case 5:
                    System.out.println("Keluar...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Pilihan tidak valid. Silakan pilih kembali.");
            }
        }
    }

    static void initDaftarKendaraan() {
        daftarKendaraan.add(new BarangRental("S 4567 YV", "Honda Beat", "Motor", 2017, 10000));
        daftarKendaraan.add(new BarangRental("N 4511 VS", "Honda Vario", "Motor", 2018, 10000));
        daftarKendaraan.add(new BarangRental("IN 1453 AA", "Toyota Yaris", "Mobil", 2022, 30000));
        daftarKendaraan.add(new BarangRental("AB 4321 A", "Toyota Innova", "Mobil", 2019, 60000));
        daftarKendaraan.add(new BarangRental("B 1234 AG", "Toyota Avanza", "Mobil", 2021, 25000));
    }

    static void tampilkanDaftarKendaraan() {
        System.out.println("--------------------------");
        System.out.println("DAFTAR KENDARAAN RENTAL SS");
        System.out.println("--------------------------");
        System.out.println("\nNomor TNKB\tNama Kendaraan\tJenis\tTahun\tBiaya Sewa Perjam");
        for (BarangRental kendaraan : daftarKendaraan) {
            System.out.println(kendaraan);
        }
    }

    static void melakukanPeminjaman(Scanner scanner) {
        System.out.println("------------------------");
        System.out.println("MASUKKAN DATA PEMINJAM");
        System.out.println("-------------------------");
        scanner.nextLine(); // Consume newline left-over
        System.out.print("Masukkan Nama Peminjam: ");
        String namaPeminjam = scanner.nextLine();
        System.out.print("Masukkan Nomor TNKB Kendaraan: ");
        String nomorTNKB = scanner.nextLine();
        System.out.print("Masukkan Lama Pinjam (jam): ");
        int lamaPinjam = scanner.nextInt();
        scanner.nextLine(); // Consume newline left-over
        System.out.print("Apakah Memerlukan Helm (ya/tidak): ");
        String memerlukanHelmStr = scanner.nextLine();
        boolean memerlukanHelm = memerlukanHelmStr.equalsIgnoreCase("ya");

        // Validasi nomor TNKB kendaraan
        boolean kendaraanDitemukan = false;
        for (BarangRental kendaraan : daftarKendaraan) {
            if (kendaraan.nomorTNKB.equals(nomorTNKB)) {
                kendaraanDitemukan = true;
                break;
            }
        }

        if (!kendaraanDitemukan) {
            System.out.println("Kendaraan dengan nomor TNKB tersebut tidak tersedia.");
            return;
        }

        // Buat transaksi baru dan tambahkan ke daftar transaksi
        Transaksi transaksi = new Transaksi(namaPeminjam, nomorTNKB, lamaPinjam, memerlukanHelm);
        daftarTransaksi.add(transaksi);
        System.out.println("\nPeminjaman berhasil dicatat.");

        // Tampilkan detail transaksi yang baru saja dilakukan
        System.out.println("\nDetail Transaksi:");
        System.out.println(transaksi);
    }

    static void tampilkanSeluruhTransaksi() {
        System.out.println("----------------------");
        System.out.println("SELURUH TRANSAKSI");
        System.out.println("----------------------");
        for (Transaksi transaksi : daftarTransaksi) {
            System.out.println("\nDetail Transaksi:");
            System.out.println(transaksi);
            System.out.println("----------------------");
        }
    }

    static void urutkanTransaksiBerdasarkanTNKB() {
        Collections.sort(daftarTransaksi, Comparator.comparing(t -> t.nomorTNKB));
        System.out.println("\nDaftar transaksi telah diurutkan berdasarkan nomor TNKB.");
        tampilkanSeluruhTransaksi();
    }
}
