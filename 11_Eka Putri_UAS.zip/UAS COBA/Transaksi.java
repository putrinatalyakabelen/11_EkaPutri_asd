public class Transaksi {
         String namaPeminjam;
        String nomorTNKB;
        int lamaPinjam;
        boolean memerlukanHelm;
    
        public Transaksi(String namaPeminjam, String nomorTNKB, int lamaPinjam, boolean memerlukanHelm) {
            this.namaPeminjam = namaPeminjam;
            this.nomorTNKB = nomorTNKB;
            this.lamaPinjam = lamaPinjam;
            this.memerlukanHelm = memerlukanHelm;
        }
    
        @Override
        public String toString() {
            return String.format("Nama Peminjam: %s\nNomor TNKB: %s\nLama Pinjam: %d jam\nMemerlukan Helm: %s",
                    namaPeminjam, nomorTNKB, lamaPinjam, memerlukanHelm ? "Ya" : "Tidak");
        }
    }
    
    
