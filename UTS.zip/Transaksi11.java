import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Transaksi11 {
     double saldo;
     double saldoAwal;
     double saldoAkhir;
     String tanggalTransaksi;
     String type;

    // Konstruktor Transaksi
    public Transaksi11(double saldo, double saldoAwal, double saldoAkhir, String tanggalTransaksi, String type) {
        this.saldo = saldo;
        this.saldoAwal = saldoAwal;
        this.saldoAkhir = saldoAkhir;
        this.tanggalTransaksi = tanggalTransaksi;
        this.type = type;
    }

    // Metode untuk menampilkan informasi transaksi
    public void displayInfo() {
        System.out.println("Saldo: " + saldo);
        System.out.println("Saldo Awal: " + saldoAwal);
        System.out.println("Saldo Akhir: " + saldoAkhir);
        System.out.println("Tanggal Transaksi: " + tanggalTransaksi);
        System.out.println("Type: " +type);
    }
}