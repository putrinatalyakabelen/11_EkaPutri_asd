package LinkedList;

public class Node11 {
   
        private Buku11 data;
        private Node11 next;
    
        public Node11(Buku11 data) {
            this.data = data;
            this.next = null;
        }
    
        public Buku11 getData() {
            return data;
        }
    
        public void setData(Buku11 data) {
            this.data = data;
        }
    
        public Node11 getNext() {
            return next;
        }
    
        public void setNext(Node11 next) {
            this.next = next;
        }
    }
