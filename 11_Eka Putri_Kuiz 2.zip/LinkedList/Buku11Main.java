package LinkedList;

import java.util.Scanner;

public class Buku11Main {

    public static void main(String[] args) {
        LinkedList11 bukuList = new LinkedList11();
        Scanner scanner = new Scanner(System.in);
      
        bukuList.add(new Buku11("978-1-23456-789-0", "Hujan", "Tere Liye"));
        bukuList.add(new Buku11("978-1-23456-789-1", "Bumi", "Tere Liye"));
        bukuList.add(new Buku11("978-1-23456-789-2", "Pulang", "Leila S. Chudori"));
        bukuList.add(new Buku11("978-1-23456-789-3", "Laskar Pelangi", "Andrea Hirata"));

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Tambah Buku");
            System.out.println("2. Hapus Buku");
            System.out.println("3. Cari Buku Berdasarkan Judul");
            System.out.println("4. Tampilkan Semua Buku");
            System.out.println("5. Urutkan Buku Berdasarkan Judul");
            System.out.println("6. Keluar");
            System.out.print("Pilih opsi: ");
            int pilihan = scanner.nextInt();
            scanner.nextLine();

            switch (pilihan) {
                case 1:
                    System.out.print("Masukkan ISBN: ");
                    String isbn = scanner.nextLine();
                    System.out.print("Masukkan Judul: ");
                    String judul = scanner.nextLine();
                    System.out.print("Masukkan Penulis: ");
                    String penulis = scanner.nextLine();
                    bukuList.add(new Buku11(isbn, judul, penulis));
                    System.out.println("Buku berhasil ditambahkan!");
                    break;
                case 2:
                    System.out.print("Masukkan ISBN buku yang ingin dihapus: ");
                    String isbnHapus = scanner.nextLine();
                    bukuList.remove(isbnHapus);
                    System.out.println("Buku berhasil dihapus!");
                    break;
                case 3:
                    System.out.print("Masukkan Judul buku yang ingin dicari: ");
                    String judulCari = scanner.nextLine();
                    LinkedList11 hasilCari = bukuList.search(judulCari);
                    System.out.println("Hasil pencarian untuk judul \"" + judulCari + "\":");
                    hasilCari.printAll();
                    break;
                case 4:
                    System.out.println("Daftar semua buku:");
                    bukuList.printAll();
                    break;
                case 5:
                    bukuList.sort();
                    break;
                case 6:
                    System.out.println("Keluar dari program.");
                    scanner.close();
                    return;
                default:
                    System.out.println("Pilihan tidak valid. Silakan coba lagi.");
            }
        }
    }
}