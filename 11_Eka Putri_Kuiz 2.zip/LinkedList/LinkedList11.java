package LinkedList;

public class LinkedList11 {
    private Node11 head;

    public LinkedList11() {
        this.head = null;
    }

    public void add(Buku11 buku) {
        Node11 newNode = new Node11(buku);
        if (head == null) {
            head = newNode;
        } else {
            Node11 current = head;
            while (current.getNext() != null) {
                current = current.getNext();
            }
            current.setNext(newNode);
        }
    }

    public void remove(String isbn) {
        if (head == null) return;

        if (head.getData().getIsbn().equals(isbn)) {
            head = head.getNext();
            return;
        }

        Node11 current = head;
        while (current.getNext() != null && !current.getNext().getData().getIsbn().equals(isbn)) {
            current = current.getNext();
        }

        if (current.getNext() != null) {
            current.setNext(current.getNext().getNext());
        }
    }

    public Buku11 get(String isbn) {
        Node11 current = head;
        while (current != null) {
            if (current.getData().getIsbn().equals(isbn)) {
                return current.getData();
            }
            current = current.getNext();
        }
        return null;
    }

    public void printAll() {
        Node11 current = head;
        while (current != null) {
            System.out.println(current.getData());
            current = current.getNext();
        }
    }

    public void sort() {
        if (head == null || head.getNext() == null) return;

        boolean swapped;
        do {
            swapped = false;
            Node11 current = head;
            while (current.getNext() != null) {
                if (current.getData().getJudul().compareTo(current.getNext().getData().getJudul()) > 0) {
                    Buku11 temp = current.getData();
                    current.setData(current.getNext().getData());
                    current.getNext().setData(temp);
                    swapped = true;
                }
                current = current.getNext();
            }
        } while (swapped);

        System.out.println("Daftar buku setelah diurutkan berdasarkan judul:");
        printAll();
    }

    public LinkedList11 search(String judul) {
        LinkedList11 result = new LinkedList11();
        Node11 current = head;
        while (current != null) {
            if (current.getData().getJudul().toLowerCase().contains(judul.toLowerCase())) {
                result.add(current.getData());
            }
            current = current.getNext();
        }
        return result;
    }
}