package JavaCollection;

import java.util.List;
import java.util.Scanner;

public class BukuArray11Main {
    public static void main(String[] args) {
        BukuService11 service = new BukuService11();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("==================");
            System.out.println("\n-MENU-:");
            System.out.println("==================");
            System.out.println("1. Tambah Buku");
            System.out.println("2. Hapus Buku");
            System.out.println("3. Cari Buku Berdasarkan Judul");
            System.out.println("4. Tampilkan Semua Buku");
            System.out.println("5. Urutkan Buku Berdasarkan Judul");
            System.out.println("6. Keluar");
            System.out.print("Pilih opsi: ");
            int pilihan = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (pilihan) {
                case 1:
                    System.out.print("Masukkan ISBN: ");
                    String isbn = scanner.nextLine();
                    System.out.print("Masukkan Judul: ");
                    String judul = scanner.nextLine();
                    System.out.print("Masukkan Penulis: ");
                    String penulis = scanner.nextLine();
                    service.tambahBuku(new Buku11(isbn, judul, penulis));
                    System.out.println("Buku berhasil ditambahkan!");
                    break;

                case 2:
                    System.out.print("Masukkan ISBN buku yang ingin dihapus: ");
                    String isbnHapus = scanner.nextLine();
                    service.hapusBuku(isbnHapus);
                    System.out.println("Buku berhasil dihapus!");
                    break;

                case 3:
                    System.out.print("Masukkan Judul buku yang ingin dicari: ");
                    String judulCari = scanner.nextLine();
                    List<Buku11> hasilCari = service.cariBukuByJudul(judulCari);
                    System.out.println("Hasil pencarian untuk judul \"" + judulCari + "\":");
                    for (Buku11 buku : hasilCari) {
                        System.out.println(buku);
                    }
                    break;

                case 4:
                    System.out.println("Daftar semua buku:");
                    service.cetakSemuaBuku();
                    break;

                case 5:
                    service.urutkanBukuByJudul();
                    break;

                case 6:
                    System.out.println("Keluar dari program.");
                    scanner.close();
                    return;

                default:
                    System.out.println("Pilihan tidak valid. Silakan coba lagi.");
            }
        }
    }
}
