package JavaCollection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class BukuService11 {
    private List<Buku11> bukuList;

    public BukuService11() {
        bukuList = new ArrayList<>();
       
        tambahBuku(new Buku11("978-1-23456-789-0", "Hujan", "Tere Liye"));
        tambahBuku(new Buku11("978-1-23456-789-1", "Harry Potter", "JK Rowling"));
        tambahBuku(new Buku11("978-1-23456-789-2", "Pulang", "Leila S. Chudori"));
        tambahBuku(new Buku11("978-1-23456-789-3", "Laskar Pelangi", "Andrea Hirata"));
    }
    
    public void tambahBuku(Buku11 buku) {
        bukuList.add(buku);
    }
    
    public void hapusBuku(String isbn) {
        bukuList.removeIf(buku -> buku.getIsbn().equals(isbn));
    }
    
    public Buku11 aksesBuku(String isbn) {
        for (Buku11 buku : bukuList) {
            if (buku.getIsbn().equals(isbn)) {
                return buku;
            }
        }
        return null;
    }
    
    public void cetakSemuaBuku() {
        for (Buku11 buku : bukuList) {
            System.out.println(buku);
        }
    }
    
    public void urutkanBukuByJudul() {
        bukuList.sort(Comparator.comparing(Buku11::getJudul));
        System.out.println("Daftar buku setelah diurutkan berdasarkan judul:");
        cetakSemuaBuku();
    }
    
    public List<Buku11> cariBukuByJudul(String judul) {
        List<Buku11> hasilCari = new ArrayList<>();
        for (Buku11 buku : bukuList) {
            if (buku.getJudul().toLowerCase().contains(judul.toLowerCase())) {
                hasilCari.add(buku);
            }
        }
        return hasilCari;
    }
}
